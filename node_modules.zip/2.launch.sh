#! /bin/sh
node index.js
exit 0