module.exports = {
    VK_TOKEN: "cf52a774e3b5979a497bdb63684ae4f078e66d8727940e22d8bea7dba2d39be6e2d8b2cef5a2c95259c05",
    DONEURL: ""
};
